from flask import Flask, request, redirect, render_template
from pymongo import MongoClient

app = Flask(__name__)

# MongoDB connection 
client = MongoClient('mongodb://localhost:27017/')
db = client['UserDatabase']
collection = db['UserExpenses']

@app.route("/")

def index():
    return render_template("index.html")

@app.route("/submit", methods = ["POST"])
def submit(): 
    if request.method == "POST":
        data = {
            'age': int(request.form['age']),
            'gender': request.form['gender'],
            'total_income': float(request.form['total_income']),
            'expenses':{
                'utilities': float(request.form.get('utilities', 0)),
                'entertainment': float(request.form.get('entertainment', 0)),
                'school_fees': float(request.form.get('school_fees',0)),
                'shopping': float(request.form.get('shopping', 0)),
                'healthcare': float(request.form.get('healthcare', 0))
            }
        }
        collection.insert_one(data)
        return redirect ('/')
    return "Error: Submission failed"

if __name__ =='__main__':
    app.run(debug = True, port= 5000) 